package com.amrita.jpl.cys21040.p2;

import java.io.IOException;

abstract class QuizGame {

    void startGame() throws IOException {}

    public void askQuestions(){}

    void evaluateAnswer(String answer){}


}
